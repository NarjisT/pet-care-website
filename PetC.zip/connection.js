const mongoose = require("mongoose");

async function connector(url){
    return mongoose.connect(url);
}

module.exports={
    connector,
}