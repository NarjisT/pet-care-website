const express = require("express");
const path = require("path");
const cookieParser = require("cookie-parser");

const app = express();
const PORT = 6001;

const { connector } = require("./connection")
connector("mongodb://127.0.0.1:27017/hack1")
    .then((res) => console.log("..MONGO..connected"))
    .catch((err) => console.log(err));

//middlewear
app.use(express.static('public'));//view engine setup
app.set("view engine", "ejs");
app.set("views", path.resolve("./views"));

//encoder setup
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.json());

//test routes
const {test}=require("./routes/testrouts")
const {router}=require("./routes/main")

app.use("/",test,router)

app.listen(PORT, () => console.log(`Server started at ${PORT}`));