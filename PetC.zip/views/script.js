// Handle form submission
document.getElementById('reportForm').addEventListener('submit', function (e) {
    e.preventDefault();
  
    // Get form data
    const reportType = document.getElementById('reportType').value;
    const species = document.getElementById('species').value;
    const petName = document.getElementById('petName').value || 'N/A';
    const dateSeen = document.getElementById('dateSeen').value;
    const location = document.getElementById('location').value;
    const contact = document.getElementById('contact').value;
    const description = document.getElementById('description').value || 'No additional details';
  
    // Create report summary
    const reportSummary = `
      📢 New Report Submitted!
      ------------------------
      📌 Report Type: ${reportType}
      🐾 Species: ${species}
      🐶 Pet Name: ${petName}
      📅 Date Last Seen: ${dateSeen}
      📍 Location: ${location}
      📞 Contact: ${contact}
      📝 Description: ${description}
    `;
  
    // Show alert (can be replaced with API call or save to database)
    alert(reportSummary);
  
    // Clear form after submission
    document.getElementById('reportForm').reset();
  });