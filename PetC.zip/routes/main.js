const express=require("express")
const router=express.Router()

//codedfunctions controller
const {uploadnews,addnews}=require("../controllers/newscontroller")
const {uploadreport,addreport,uploadadopt}=require("../controllers/reportcontroller")

router.route("/news")
.get(uploadnews)
.post(addnews)

router.get("/home",(req,res)=>{
    return res.status(200).render("home2")
})

router.get("/adopt",uploadadopt)
router.get("/organization",(req,res)=>{
    return res.status(200).render("organization")
})
router.route("/report")
.get(uploadreport)
.post(addreport)



module.exports={
    router
}