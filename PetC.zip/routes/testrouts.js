const { addnews,uploadnews} = require("../controllers/newscontroller")
const { addreport,uploadreport} = require("../controllers/reportcontroller")
const express=require("express")
const test=express.Router()

test.post("/addnews",addnews)
test.get("/addnews",uploadnews)
test.post("/addreport",addreport)
test.get("/addreport",uploadreport)


module.exports={
    test,
}