const {news}=require("../models/news")

async function addnews(req,res){
    const body=req.body;
    if(!body.description||!body.location)return res.json({msg:"all fields req"});
    const result=await news.create({
        description:body.description,
        location:body.location
    })  
    return res.status(200).redirect("/news")
}

async function uploadnews(req,res){
    const finalnews=await news.find({});
    return res.status(200).render("news",{
        news:finalnews,
    });
}

module.exports={
    addnews,
    uploadnews
}