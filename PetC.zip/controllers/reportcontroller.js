const {report}=require("../models/report")

async function addreport(req,res){
    const body=req.body;
    if(!body.name||!body.location||!body.contact)return res.json({msg:"all fields req"});
    const result=await report.create({
        name:body.name,
        location:body.location,
        contact:body.contact
    })  
    return res.status(200).redirect("/report")
}

async function uploadreport(req,res){
    const reports=await report.find({});
    return res.status(200).render("report");
}
async function uploadadopt(req,res){
    const reports=await report.find({});
    return res.status(200).render("adopt",{
        adopt:reports,
    });
}


module.exports={
    addreport,
    uploadreport,
    uploadadopt
}