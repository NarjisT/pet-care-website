const mongoose=require("mongoose")

const schema2=new mongoose.Schema({
    description:{
        type:String,
        required:true
    },
    location:{
        type:String,
        required:true
    }
})

const news=mongoose.model("news",schema2)

module.exports={
    news,
}